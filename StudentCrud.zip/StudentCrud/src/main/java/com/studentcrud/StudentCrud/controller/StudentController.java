package com.studentcrud.StudentCrud.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.studentcrud.StudentCrud.model.Student;
import com.studentcrud.StudentCrud.service.StudentService;

//mark class as Controller  
@RestController
public class StudentController {

	//autowire the StudentService class  
	@Autowired
	private StudentService studentService;

	//creating post mapping that post the student detail in the database  
	@PostMapping("/student")
	public String createNewStudents(@RequestBody Student student) {
		try {
			return studentService.createNewStudents(student);
		} catch (Exception e) {

			return "can't creating new students" + e.getMessage();
		}
	}

	//creating a get mapping that retrieves all the students detail from the database  
	@GetMapping("/students")
	public ResponseEntity<List<Student>> getAllStudents() {
		try {
			return studentService.getAllStudents();
		} catch (Exception e) {
			return null;
		}
	}

	//creating a get mapping that retrieves the detail of a specific student
	@GetMapping("/student/{studId}")
	public ResponseEntity<Student> getStudentById(@PathVariable long studId) {
		try {
			return studentService.getStudentById(studId);
		} catch (Exception e) {
			return null;
		}
	}

	
	//creating put mapping that updates the student detail   
	@PutMapping("/student")
	public String updateStudentById(@RequestBody Student student) {
		try {
			return studentService.updateStudentById(student);
		} catch (Exception e) {
			return "error whileing updated student" + e.getMessage();
		}
	}

	
	//creating a delete mapping that deletes a specified student  
	@DeleteMapping("/student/{studId}")
	public String deleteStduentById(@PathVariable Long studId) {
		try {
			return studentService.deleteStudentById(studId);
		} catch (Exception e) {
			return "can't deleted record" + e.getMessage();
		}
	}

	//creating a delete mapping that delete all students  
	@DeleteMapping("/students")
	public String deleteAllStudents() {
		try {
			return studentService.deleteAllStudent();
		} catch (Exception e) {
			return "can't delete all records" + e.getMessage();
		}

	}
	

	//creating a delete mapping that delete student using parameter  
	@DeleteMapping("/deletestudent")
	public String deleteStduentByUsingRequestParameter(@RequestParam Long studId) {
		try {
			return studentService.deleteStduentByParam(studId);
		} catch (Exception e) {
			return "can't delete record " + e.getMessage();
		}

	}

}
