package com.studentcrud.StudentCrud.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//mark class as an Entity 
@Entity

//defining Student Table name 
@Table(name = "Student")
public class Student {

	// Defining book id as primary key
	@Id
	private long studId;

	@Column(name = "studName")
	private String studName;

	@Column(name = "studAge")
	private int studAge;

	@Column(name = "studGender")
	private String studGender;

	@Column(name = "studAddress")
	private String studAddress;

	public long getStudId() {
		return studId;
	}

	public void setStudId(long studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public int getStudAge() {
		return studAge;
	}

	public void setStudAge(int studAge) {
		this.studAge = studAge;
	}

	public String getStudGender() {
		return studGender;
	}

	public void setStudGender(String studGender) {
		this.studGender = studGender;
	}

	public String getStudAddress() {
		return studAddress;
	}

	public void setStudAddress(String studAddress) {
		this.studAddress = studAddress;
	}

	public Student(long studId, String studName, int studAge, String studGender, String studAddress) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studAge = studAge;
		this.studGender = studGender;
		this.studAddress = studAddress;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studAge=" + studAge + ", studGender="
				+ studGender + ", studAddress=" + studAddress + "]";
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

}
