package com.studentcrud.StudentCrud.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.studentcrud.StudentCrud.model.Student;

//repository that extends JpaRepository  
@EnableJpaRepositories
public interface StudentRepository extends JpaRepository<Student, Long> {

}
