package com.studentcrud.StudentCrud.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.studentcrud.StudentCrud.model.Student;

public interface StudentService {

	String createNewStudents(Student student);

	ResponseEntity<List<Student>> getAllStudents();

	ResponseEntity<Student> getStudentById(long studId);

	String updateStudentById(Student student);

	String deleteStudentById(Long studId);

	String deleteAllStudent();

	String deleteStduentByParam(Long studId);

}
