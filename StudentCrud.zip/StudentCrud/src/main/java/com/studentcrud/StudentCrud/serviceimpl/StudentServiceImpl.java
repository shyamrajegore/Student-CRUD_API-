package com.studentcrud.StudentCrud.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.studentcrud.StudentCrud.model.Student;
import com.studentcrud.StudentCrud.repository.StudentRepository;
import com.studentcrud.StudentCrud.service.StudentService;

//defining the business logic 
@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository studentrepository;

	// saving a specific record by using the method save() of studentrepository
	@Override
	public String createNewStudents(Student student) {
		try {
			studentrepository.save(student);
			return "student created in database";

		} catch (Exception e) {

			System.out.println(e);
			throw e;
		}
	}

	// getting all books record by using the method findAll() of studentrepository
	@Override
	public ResponseEntity<List<Student>> getAllStudents() {
		try {
			List<Student> studlist = new ArrayList<>();
			studentrepository.findAll().forEach(studlist::add);
			return new ResponseEntity<List<Student>>(studlist, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}

	}

	// getting a specific record by using the method findById() of studentrepository
	@Override
	public ResponseEntity<Student> getStudentById(long studId) {
		try {
			Optional<Student> stud = studentrepository.findById(studId);
			if (stud.isPresent()) {
				return new ResponseEntity<Student>(stud.get(), HttpStatus.FOUND);
			} else {
				return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
	}

	// updating a record
	@Override
	public String updateStudentById(Student student) {
		try {
			Optional<Student> stud = studentrepository.findById(student.getStudId());
			if (stud.isPresent()) {
				Student existStud = stud.get();
				existStud.setStudName(student.getStudName());
				existStud.setStudAge(student.getStudAge());
				existStud.setStudGender(student.getStudGender());
				existStud.setStudAddress(student.getStudAddress());
				studentrepository.save(existStud);
				return "Students Details Against Id " + student.getStudId() + " Updated";
			}

			else {
				return "Students Details does not exist for stud_id " + student.getStudId();

			}
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
	}

	// deleting a specific record by using the method deleteById() of
	// studentrepository
	@Override
	public String deleteStudentById(Long studId) {
		try {
			studentrepository.deleteById(studId);
			return "Student Deleted Successfully";
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
	}

	@Override
	public String deleteAllStudent() {
		try {
			studentrepository.deleteAll();
			return "Students Deleted Successfully";
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
	}

	// deleting a specific record by using the parameter of studentrepository
	@Override
	public String deleteStduentByParam(Long studId) {
		try {
			studentrepository.deleteById(studId);
			return "Student Deleted Successfully";
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
	}

}
